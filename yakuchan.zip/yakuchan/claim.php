<?php

include 'inc/functions.php';

error('Automatic claiming is no longer available. To claim a board, send your request to admin@8chan.co along with the IP you used to post on that board.');
